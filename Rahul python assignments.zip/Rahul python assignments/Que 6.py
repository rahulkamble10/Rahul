n=int(input("Enter a number :"))
sum=0
while n!=0:
    d=n%10
    sum=sum+(d**1)
    n=n//10
print("sum of the digits is : ",sum)
