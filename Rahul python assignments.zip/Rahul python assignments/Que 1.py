name="Utkarsh"
ID="321ABZ"
email="abc1234@gmail.com"
Designation="Faculty"
Password="zzz@123"
print("Name:",name)
print("ID:",ID)
print("email:",email)
print("Designation:",Designation)
print("Password :",Password)
