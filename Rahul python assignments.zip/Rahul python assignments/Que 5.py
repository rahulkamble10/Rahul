a=int(input("Enter number 1 :"))
b=int(input("Enter number 2 :"))
c=a+b
b=c-b
a=c-a
print("Numbers after swapping :",a,b)
