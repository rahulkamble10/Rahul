a=int(input("Enter number 1 :"))
b=int(input("Enter number 2 :"))
c=int(input("Enter number 3 :"))
if a>b and a>c:
    print(a," is greatest among all three")
elif b>a and b>c:
    print(b," is greatest among all three")
else:
    print(c," is greatest among all three")
