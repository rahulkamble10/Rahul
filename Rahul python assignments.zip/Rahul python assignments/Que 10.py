n=int(input("Enter a number :"))
temp=n
sum=0
while temp!=0:
    d=temp%10
    sum=(sum*10)+d
    temp=temp//10
if n==sum:
    print("The number is a palindrome")
else:
    print("The number is not a palindrome")
