n=int(input("Enter a number :"))
if n==0:
    print("Number is zero ")
elif n%2==0:
    print("Number is an even number ")
else:
    print("Number is odd number")
